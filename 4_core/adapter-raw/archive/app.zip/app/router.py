"""
路由器模块：基于评分决定记忆类型和等级
流程：标准化 → 过滤 → 路由 → 转换

改进 v2.2：
1. 支持 failure_experience 类型
2. 失败经验自动路由到 L2
"""
from app.config import config
from app.filter import detect_failure_content


def calculate_memory_score(content: str, metadata: dict = None) -> int:
    """
    计算记忆评分
    评分越高，内容越重要
    """
    score = 0
    rules = config.route_score_rules
    content_lower = content.lower()

    # 长度评分
    if len(content) > 100:
        score += rules.get("length_gt_100", 0)
    if len(content) > 500:
        score += rules.get("length_gt_500", 0)
    if len(content) > 1000:
        score += 1

    # 成功/完成关键词
    success_keywords = ["成功", "完成", "success", "完成", "done", "completed"]
    for kw in success_keywords:
        if kw in content_lower:
            score += rules.get("success_keyword", 0)
            break

    # 策略/规划关键词
    strategy_keywords = ["策略", "规划", "policy", "strategy", "方案"]
    for kw in strategy_keywords:
        if kw in content_lower:
            score += rules.get("strategy_keyword", 0)
            break

    # 重要/关键关键词
    important_keywords = ["重要", "关键", "important", "critical", "核心"]
    for kw in important_keywords:
        if kw in content_lower:
            score += rules.get("important_keyword", 0)
            break

    # 知识/规则关键词
    knowledge_keywords = ["知识", "规则", "knowledge", "rule", "原则"]
    for kw in knowledge_keywords:
        if kw in content_lower:
            score += rules.get("knowledge_keyword", 0)
            break

    # 失败经验评分（新增：不再过滤，而是加分）
    is_failure, failure_type = detect_failure_content(content)
    if is_failure:
        score += rules.get("failure_experience", 0)

    # metadata 评分
    if metadata:
        content_type = metadata.get("type", "")
        if content_type == "strategy":
            score += rules.get("type_strategy", 0)
        elif content_type == "result":
            score += rules.get("type_result", 0)
        elif content_type == "failure_experience":
            score += rules.get("type_failure", 0)
        elif content_type == "knowledge":
            score += rules.get("type_strategy", 0)

    # 确保所有内容至少有1分
    if score == 0:
        score = 1

    return score


def get_memory_level(score: int) -> str:
    """
    根据评分获取记忆等级

    L0: 0分 - 垃圾/不存
    L1: 1-2分 - 短期缓存
    L2: 3-4分 - 经验记忆
    L3: 5+分 - 核心知识
    """
    if score <= 0:
        return "L0"
    elif score <= 2:
        return "L1"
    elif score <= 4:
        return "L2"
    else:
        return "L3"


def route_memory_type_and_level(content: str, metadata: dict = None) -> tuple[str, str, int]:
    """
    路由：决定记忆类型和等级

    返回: (memory_type, memory_level, score)
    - memory_type: "long_term" 或 "short_term"
    - memory_level: "L0", "L1", "L2", "L3"
    - score: 计算出的评分

    改进：失败经验自动进入长期记忆
    """
    # 计算评分
    score = calculate_memory_score(content, metadata)

    # 检测失败内容
    is_failure, failure_type = detect_failure_content(content)

    # 如果是失败经验，强制提高评分确保进入 L2
    if is_failure and score < 3:
        score = 3  # 失败经验最低进入 L2

    # 决定记忆类型
    memory_type = "long_term" if score >= config.long_term_threshold else "short_term"

    # 决定记忆等级
    memory_level = get_memory_level(score)

    return memory_type, memory_level, score
