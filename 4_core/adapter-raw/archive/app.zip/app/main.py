"""
Memory Adapter v2.2 - OpenViking 中间层
功能：标准化 → 过滤 → 路由 → 转换

改进点 v2.2（相比 v2.1）：
1. 错误内容不再过滤，转换为 failure_experience 类型并加分
2. 失败经验自动进入 L2（经验记忆）
3. 支持检测失败内容并标记

处理流程：
标准化 → 过滤 → 去重 → 限流 → 路由 → 转换 → OpenViking
"""
import asyncio
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Any, Dict
from datetime import datetime
from urllib.parse import quote
from uuid import uuid4
import httpx
import loguru
import sys
import os
import re
from pathlib import PurePosixPath
from collections import deque

from app.config import config
from app.filter import should_store, detect_failure_content
from app.normalizer import normalize, to_viking_format, parse_viking_response, calculate_expire_at
from app.router import route_memory_type_and_level
from app.dedup import check_duplicate, add_to_dedup, get_dedup_cache
from app.v2_query import (
    generate_meter_artifact,
    store_meter,
    get_meter,
    get_tenant_usage,
    get_trend_data,
    build_packed_context,
    check_quota_enforcement,
)
from app.access import get_tenant_registry_entry, resolve_query_access

# 日志配置
loguru.logger.remove()
loguru.logger.add(
    sys.stderr,
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>"
)


class SupportAPIError(Exception):
    """统一的售后可追踪错误。"""

    def __init__(self, status_code: int, payload: Dict[str, Any]):
        self.status_code = status_code
        self.payload = payload
        super().__init__(payload.get("message") or payload.get("detail") or "support_api_error")


app = FastAPI(
    title="Memory Adapter v2.2",
    description="OpenViking 中间层：标准化 → 过滤 → 去重 → 限流 → 路由 → 转换",
    version="2.2.0"
)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def attach_request_id(request: Request, call_next):
    request.state.request_id = uuid4().hex
    response = await call_next(request)
    response.headers["X-Request-ID"] = request.state.request_id
    return response


@app.exception_handler(SupportAPIError)
async def support_api_error_handler(request: Request, exc: SupportAPIError):
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.payload,
        headers={"X-Request-ID": get_request_id(request) or ""},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    payload = build_support_payload(
        request,
        "ADAPTER_REQUEST_VALIDATION_FAILED",
        "Request validation failed",
        operation="request_validation",
        detail=str(exc),
        retryable=False,
    )
    return JSONResponse(
        status_code=422,
        content=payload,
        headers={"X-Request-ID": get_request_id(request) or ""},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    payload = build_support_payload(
        request,
        "ADAPTER_INTERNAL_ERROR",
        "Unhandled adapter error",
        operation="unhandled_exception",
        detail=f"{type(exc).__name__}: {exc}",
        retryable=False,
    )
    log_error("Unhandled adapter exception", payload["detail"])
    return JSONResponse(
        status_code=500,
        content=payload,
        headers={"X-Request-ID": get_request_id(request) or ""},
    )


# ==================== 限流器 ====================

class RateLimiter:
    """滑动窗口限流器"""

    def __init__(self, max_per_minute: int = 100):
        self.max_per_minute = max_per_minute
        self.requests = deque()

    def is_allowed(self) -> bool:
        """检查是否允许写入"""
        now = datetime.now().timestamp()
        one_minute_ago = now - 60

        # 清理超过 1 分钟的请求
        while self.requests and self.requests[0] < one_minute_ago:
            self.requests.popleft()

        # 检查是否超过限制
        if len(self.requests) >= self.max_per_minute:
            return False

        # 记录本次请求
        self.requests.append(now)
        return True

    def get_current_count(self) -> int:
        """获取当前分钟内的请求数"""
        now = datetime.now().timestamp()
        one_minute_ago = now - 60

        # 清理超过 1 分钟的请求
        while self.requests and self.requests[0] < one_minute_ago:
            self.requests.popleft()

        return len(self.requests)


# 全局限流器
_rate_limiter = RateLimiter(max_per_minute=config.rate_limit_per_minute)


# ==================== 请求/响应模型 ====================

class MemoryRequest(BaseModel):
    """记忆写入请求"""
    agent: str = "unknown"
    type: str = "general"
    content: str
    tags: List[str] = []
    memory_type: Optional[str] = None  # 可显式指定
    timestamp: Optional[int] = None


class MemoryResponse(BaseModel):
    """记忆写入响应"""
    status: str  # "stored", "skipped", "duplicate", "rate_limited", "error"
    reason: Optional[str] = None
    memory_id: Optional[str] = None
    memory_type: Optional[str] = None
    memory_level: Optional[str] = None
    memory_expire_at: Optional[int] = None
    score: Optional[int] = None
    is_failure: Optional[bool] = None  # 新增：是否失败经验
    uri: Optional[str] = None  # 兼容 OpenClaw 插件期望字段
    request_id: Optional[str] = None
    error_code: Optional[str] = None
    support: Optional[Dict[str, Any]] = None


class RetrieveRequest(BaseModel):
    """记忆查询请求"""
    query: Optional[str] = None
    uri: Optional[str] = None
    agent: Optional[str] = None  # Agent 隔离
    memory_type: Optional[str] = None  # 记忆类型过滤
    memory_level: Optional[str] = None  # 记忆等级过滤
    include_expired: bool = False  # 是否包含过期记忆
    limit: int = 10
    scoreThreshold: Optional[float] = None


class DeleteRequest(BaseModel):
    """按 URI 删除记忆"""
    uri: str


class SnapshotRequest(BaseModel):
    """生成 MEMORY.md 启动快照"""
    agent: str = "supervisor"
    limit: int = 200


class MemoryQueryRequest(BaseModel):
    """V2: Unified memory query request with optimization."""
    tenant: str
    user: str
    agent: str = "supervisor"
    query: str
    context: Optional[Dict[str, Any]] = None
    options: Optional[Dict[str, Any]] = None


class MemoryQueryResponse(BaseModel):
    """V2: Unified memory query response with token savings."""
    request_id: str
    selected_memories: List[Dict[str, Any]]
    packed_context: str
    memory_tokens_injected: int
    tokens_saved_estimate: int
    savings_ratio: float
    explanation: Dict[str, Any]
    meter_artifact: Dict[str, Any]


# ==================== 工具函数 ====================

SUPPORT_SCHEMA_VERSION = "ov-support/v1"
SUPPORT_ERROR_CATALOG: Dict[str, Dict[str, Any]] = {
    "ADAPTER_BAD_REQUEST": {
        "category": "input",
        "severity": "low",
        "retryable": False,
        "suggested_action": "修正请求参数后重试。",
    },
    "ADAPTER_REQUEST_VALIDATION_FAILED": {
        "category": "input",
        "severity": "low",
        "retryable": False,
        "suggested_action": "按接口要求补齐必填字段并修正字段类型。",
    },
    "ADAPTER_SEARCH_FAILED": {
        "category": "dependency",
        "severity": "medium",
        "retryable": True,
        "suggested_action": "检查 OpenViking 搜索状态、索引窗口与 Adapter health。",
    },
    "ADAPTER_READ_FAILED": {
        "category": "dependency",
        "severity": "medium",
        "retryable": True,
        "suggested_action": "检查下游读取接口与目标 URI 是否仍存在。",
    },
    "ADAPTER_DELETE_FAILED": {
        "category": "dependency",
        "severity": "medium",
        "retryable": True,
        "suggested_action": "检查下游删除接口、URI 正确性与命名空间状态。",
    },
    "ADAPTER_SNAPSHOT_FAILED": {
        "category": "dependency",
        "severity": "medium",
        "retryable": True,
        "suggested_action": "检查 OpenViking 文件系统可用性与命名空间遍历状态。",
    },
    "ADAPTER_NAMESPACE_PREPARE_FAILED": {
        "category": "runtime",
        "severity": "high",
        "retryable": True,
        "suggested_action": "检查命名空间根路径配置与 OpenViking 文件系统写权限。",
    },
    "ADAPTER_VIKING_UPLOAD_FAILED": {
        "category": "dependency",
        "severity": "high",
        "retryable": True,
        "suggested_action": "检查 OpenViking 上传接口与临时存储状态。",
    },
    "ADAPTER_VIKING_COMMIT_FAILED": {
        "category": "dependency",
        "severity": "high",
        "retryable": True,
        "suggested_action": "检查 OpenViking 提交链路、commit timeout 与上游负载。",
    },
    "ADAPTER_VIKING_UNAVAILABLE": {
        "category": "dependency",
        "severity": "high",
        "retryable": True,
        "suggested_action": "确认 OpenViking 服务在线且网络可达。",
    },
    "ADAPTER_VIKING_TIMEOUT": {
        "category": "dependency",
        "severity": "high",
        "retryable": True,
        "suggested_action": "提升相关 timeout 或排查 OpenViking 提交/索引时延。",
    },
    "ADAPTER_INTERNAL_ERROR": {
        "category": "runtime",
        "severity": "high",
        "retryable": False,
        "suggested_action": "记录 request_id 并结合 Adapter 日志做进一步排障。",
    },
    "ADAPTER_QUOTA_EXCEEDED": {
        "category": "quota",
        "severity": "high",
        "retryable": False,
        "suggested_action": "升级订阅计划或等待下个计费周期重置配额。",
    },
}


def get_request_id(request: Optional[Request]) -> Optional[str]:
    if request is None:
        return None
    return getattr(getattr(request, "state", None), "request_id", None)


def build_support_payload(
    request: Optional[Request],
    code: str,
    message: str,
    *,
    operation: str,
    detail: Optional[str] = None,
    upstream_status: Optional[int] = None,
    retryable: Optional[bool] = None,
    suggested_action: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    catalog = SUPPORT_ERROR_CATALOG.get(code, SUPPORT_ERROR_CATALOG["ADAPTER_INTERNAL_ERROR"])
    effective_retryable = catalog["retryable"] if retryable is None else retryable
    effective_suggested_action = suggested_action or catalog["suggested_action"]
    payload: Dict[str, Any] = {
        "schema_version": SUPPORT_SCHEMA_VERSION,
        "status": "error",
        "message": message,
        "detail": detail or message,
        "error_code": code,
        "request_id": get_request_id(request),
        "support": {
            "category": catalog["category"],
            "severity": catalog["severity"],
            "retryable": effective_retryable,
            "operation": operation,
            "suggested_action": effective_suggested_action,
        },
    }
    if upstream_status is not None:
        payload["support"]["upstream_status"] = upstream_status
    if extra:
        payload["support"]["context"] = extra
    return payload


def build_memory_error_response(
    request: Optional[Request],
    code: str,
    reason: str,
    *,
    operation: str,
    detail: Optional[str] = None,
    suggested_action: Optional[str] = None,
    upstream_status: Optional[int] = None,
) -> MemoryResponse:
    support_payload = build_support_payload(
        request,
        code,
        detail or reason,
        operation=operation,
        detail=detail or reason,
        upstream_status=upstream_status,
        suggested_action=suggested_action,
    )
    return MemoryResponse(
        status="error",
        reason=reason,
        request_id=get_request_id(request),
        error_code=code,
        support=support_payload["support"],
    )


def raise_support_api_error(
    request: Optional[Request],
    status_code: int,
    code: str,
    message: str,
    *,
    operation: str,
    detail: Optional[str] = None,
    upstream_status: Optional[int] = None,
    retryable: Optional[bool] = None,
    suggested_action: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    payload = build_support_payload(
        request,
        code,
        message,
        operation=operation,
        detail=detail,
        upstream_status=upstream_status,
        retryable=retryable,
        suggested_action=suggested_action,
        extra=extra,
    )
    raise SupportAPIError(status_code=status_code, payload=payload)

def log_stored(Agent: str, memory_type: str, memory_level: str, score: int, is_failure: bool = False):
    """记录存储成功"""
    failure_tag = " [FAILURE_EXPERIENCE]" if is_failure else ""
    loguru.logger.info(f"[STORED]{failure_tag} agent={Agent}, type={memory_type}, level={memory_level}, score={score}")


def log_filtered(reason: str, content_preview: str = ""):
    """记录过滤原因"""
    preview = content_preview[:50] + "..." if len(content_preview) > 50 else content_preview
    loguru.logger.warning(f"[FILTERED] reason={reason}, preview={preview}")


def log_error(error: str, detail: str = ""):
    """记录错误"""
    loguru.logger.error(f"[ERROR] {error}: {detail}")


def build_timeout(total_seconds: float) -> httpx.Timeout:
    """统一构建下游请求 timeout，避免散落的硬编码常量。"""
    total = max(total_seconds, config.viking_connect_timeout_seconds)
    return httpx.Timeout(
        timeout=total,
        connect=min(config.viking_connect_timeout_seconds, total),
        read=total,
        write=total,
        pool=min(config.viking_connect_timeout_seconds, total),
    )


def log_slow_request(operation: str, elapsed_ms: float, timeout_seconds: float):
    """记录慢请求，帮助后续收敛 timeout 与索引延迟。"""
    if elapsed_ms >= config.slow_request_threshold_ms:
        loguru.logger.warning(
            f"[SLOW_REQUEST] op={operation}, elapsed_ms={elapsed_ms:.0f}, timeout_s={timeout_seconds}"
        )


async def viking_request(
    method: str,
    path: str,
    *,
    operation: str,
    timeout_seconds: float,
    retryable: bool = True,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
    **kwargs,
) -> httpx.Response:
    """统一封装对 OpenViking 的下游调用，提供分层超时与有限重试。"""
    attempts = 1 + max(0, config.viking_retry_attempts if retryable else 0)
    backoff = max(0.0, config.viking_retry_backoff_seconds)
    last_exc: Exception | None = None
    request_headers = build_headers_with_tenant(tenant_id, user_id) if tenant_id and user_id else build_headers()

    for attempt in range(1, attempts + 1):
        started = datetime.now().timestamp()
        try:
            async with httpx.AsyncClient(timeout=build_timeout(timeout_seconds)) as client:
                response = await client.request(
                    method,
                    f"{config.viking_url}{path}",
                    headers=request_headers,
                    **kwargs,
                )
            elapsed_ms = (datetime.now().timestamp() - started) * 1000
            log_slow_request(operation, elapsed_ms, timeout_seconds)

            if retryable and response.status_code in {502, 503, 504} and attempt < attempts:
                loguru.logger.warning(
                    f"[RETRYABLE_STATUS] op={operation}, attempt={attempt}/{attempts}, status={response.status_code}"
                )
                await asyncio.sleep(backoff * attempt)
                continue
            return response
        except (httpx.TimeoutException, httpx.ConnectError, httpx.NetworkError, httpx.RemoteProtocolError) as exc:
            last_exc = exc
            loguru.logger.warning(
                f"[RETRYABLE_ERROR] op={operation}, attempt={attempt}/{attempts}, error={type(exc).__name__}: {exc}"
            )
            if attempt < attempts:
                await asyncio.sleep(backoff * attempt)
                continue
            raise

    if last_exc:
        raise last_exc
    raise RuntimeError(f"unreachable_viking_request_state:{operation}")


def build_headers() -> Dict[str, str]:
    headers: Dict[str, str] = {}
    if config.viking_api_key:
        headers["X-API-Key"] = config.viking_api_key
    return headers


def build_headers_with_tenant(tenant_id: str, user_id: str) -> Dict[str, str]:
    headers = build_headers()
    headers["X-OpenViking-Account"] = tenant_id
    headers["X-OpenViking-User"] = user_id
    return headers


def resolve_tenant_identity(request: Request) -> tuple[Optional[str], Optional[str]]:
    state = getattr(request, "state", None)
    override_tenant = getattr(state, "v2_tenant_override", None) if state else None
    override_user = getattr(state, "v2_user_override", None) if state else None
    if override_tenant and override_user:
        return override_tenant, override_user

    header_tenant = request.headers.get("X-OpenViking-Account")
    header_user = request.headers.get("X-OpenViking-User")
    if header_tenant and header_user:
        return header_tenant, header_user

    return None, None


def normalize_viking_uri(uri: str) -> str:
    normalized = (uri or "").strip()
    if normalized == "viking://":
        return normalized
    return normalized.rstrip("/")


def split_viking_uri(uri: str) -> List[str]:
    normalized = normalize_viking_uri(uri)
    if not normalized.startswith("viking://"):
        return []
    suffix = normalized[len("viking://") :]
    return [segment for segment in suffix.split("/") if segment]


def join_viking_uri(segments: List[str]) -> str:
    if not segments:
        return "viking://"
    return "viking://" + "/".join(segments)


def sanitize_path_segment(value: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in ("-", "_") else "-" for ch in (value or "").strip())
    safe = safe.strip("-_")
    return safe or "unknown"


def build_memory_root_prefix() -> str:
    return normalize_viking_uri(config.viking_memory_namespace_root)


def build_agent_memory_prefix(agent: str) -> str:
    agent_segment = sanitize_path_segment(agent)
    return f"{build_memory_root_prefix()}/{agent_segment}"


def build_memory_type_prefix(agent: str, memory_type: str) -> str:
    prefix = build_agent_memory_prefix(agent)
    type_segment = sanitize_path_segment(memory_type or "general")
    return f"{prefix}/{type_segment}"


def build_memory_resource_uri(agent: str, memory_type: str) -> str:
    prefix = build_memory_type_prefix(agent, memory_type)
    return f"{prefix}/mem-{uuid4().hex}.md"


def map_memory_level(level: Any) -> Optional[int]:
    """统一将 L1/L2/L3 或数字层级映射为插件可用的 1/2/3。"""
    if level is None:
        return None
    if isinstance(level, int):
        return level
    if isinstance(level, float):
        return int(level)
    if isinstance(level, str):
        normalized = level.strip().upper()
        if normalized.startswith("L") and normalized[1:].isdigit():
            return int(normalized[1:])
        if normalized.isdigit():
            return int(normalized)
    return None


def get_nested(data: Dict[str, Any], *paths: str) -> Any:
    for path in paths:
        value: Any = data
        ok = True
        for part in path.split("."):
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                ok = False
                break
        if ok:
            return value
    return None


def extract_response_error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except Exception:
        return (response.text or "").strip()

    if isinstance(payload, dict):
        candidates = [
            payload.get("detail"),
            payload.get("error"),
            payload.get("message"),
            get_nested(payload, "result.error"),
            get_nested(payload, "result.message"),
        ]
        for candidate in candidates:
            if isinstance(candidate, str) and candidate.strip():
                return candidate.strip()

    return (response.text or "").strip()


def is_missing_namespace_error(status_code: int, detail: str) -> bool:
    normalized = (detail or "").lower()
    if status_code == 404:
        return True
    patterns = (
        "no such directory",
        "no such file or directory",
        "not found",
    )
    return any(pattern in normalized for pattern in patterns)


def extract_memory_items(payload: Any) -> List[Dict[str, Any]]:
    """兼容多种 Viking 返回结构，提取记忆列表。"""
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []

    collected: List[Dict[str, Any]] = []
    candidates = [
        payload.get("memories"),
        get_nested(payload, "result.memories"),
        payload.get("resources"),
        get_nested(payload, "result.resources"),
        payload.get("items"),
        get_nested(payload, "result.items"),
        payload.get("results"),
        get_nested(payload, "result.results"),
    ]
    for candidate in candidates:
        if isinstance(candidate, list):
            collected.extend(item for item in candidate if isinstance(item, dict))
    return collected


def to_plugin_memory(item: Dict[str, Any]) -> Dict[str, Any]:
    """把底层返回统一成 OpenClaw 插件当前消费的数据形状。"""
    metadata = item.get("metadata", {}) if isinstance(item.get("metadata"), dict) else {}
    uri = (
        item.get("uri")
        or item.get("id")
        or metadata.get("uri")
        or metadata.get("memory_id")
        or ""
    )
    category = (
        item.get("category")
        or metadata.get("type")
        or metadata.get("memory_type")
        or item.get("context_type")
        or "memory"
    )
    raw_abstract = (
        item.get("abstract")
        or item.get("summary")
        or item.get("content")
        or item.get("text")
        or ""
    )
    raw_content = item.get("content") or item.get("text") or raw_abstract
    abstract = extract_memory_body(raw_abstract) or raw_abstract
    content = extract_memory_body(raw_content) or raw_content
    score = item.get("score")
    if score is None:
        score = item.get("similarity")
    level = (
        map_memory_level(item.get("level"))
        or map_memory_level(item.get("memory_level"))
        or map_memory_level(metadata.get("memory_level"))
        or (2 if item.get("is_leaf") else 1)
    )

    return {
        "uri": uri,
        "content": content,
        "abstract": abstract,
        "score": score,
        "category": category,
        "level": level,
        "metadata": metadata,
    }


def content_matches_query(content: str, query: str) -> bool:
    normalized_content = normalize_fact_text(content).lower()
    normalized_query = normalize_fact_text(query).lower()
    return bool(normalized_query) and normalized_query in normalized_content


async def list_directory_entries(
    uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    encoded_uri = quote(uri, safe="")
    try:
        response = await viking_request(
            "GET",
            f"/api/v1/fs/ls?uri={encoded_uri}",
            operation="list_directory_entries",
            timeout_seconds=config.viking_snapshot_timeout_seconds,
            retryable=True,
            tenant_id=tenant_id,
            user_id=user_id,
        )
    except Exception as exc:
        loguru.logger.warning(f"[LIST_DIRECTORY_ERROR] uri={uri}, error={type(exc).__name__}: {exc}")
        return []

    if not response.is_success:
        detail = extract_response_error_detail(response)
        if is_missing_namespace_error(response.status_code, detail):
            loguru.logger.info(f"[NAMESPACE_MISSING] uri={uri}, op=list_directory_entries")
            return []
        loguru.logger.warning(
            f"[LIST_DIRECTORY_FAILED] uri={uri}, status={response.status_code}, detail={compact_fact_text(detail, 120)}"
        )
        return []

    payload = response.json()
    result = get_nested(payload, "result")
    if not isinstance(result, list):
        return []
    return [item for item in result if isinstance(item, dict)]


async def namespace_exists(
    uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> bool:
    normalized = normalize_viking_uri(uri)
    segments = split_viking_uri(normalized)
    if not segments:
        return False
    if normalized == "viking://resources":
        return True

    current_parent = "viking://resources"
    for index in range(2, len(segments) + 1):
        current_uri = join_viking_uri(segments[:index])
        entries = await list_directory_entries(current_parent, tenant_id=tenant_id, user_id=user_id)
        if not any(
            normalize_viking_uri(str(item.get("uri", ""))) == current_uri
            for item in entries
        ):
            return False
        current_parent = current_uri
    return True


async def mkdir_uri(uri: str, tenant_id: Optional[str] = None, user_id: Optional[str] = None) -> bool:
    try:
        response = await viking_request(
            "POST",
            "/api/v1/fs/mkdir",
            operation="mkdir_uri",
            timeout_seconds=config.viking_resolve_timeout_seconds,
            retryable=False,
            tenant_id=tenant_id,
            user_id=user_id,
            json={"uri": uri},
        )
    except Exception as exc:
        loguru.logger.warning(f"[MKDIR_ERROR] uri={uri}, error={type(exc).__name__}: {exc}")
        return False

    if response.is_success:
        loguru.logger.info(f"[NAMESPACE_CREATED] uri={uri}")
        return True

    detail = extract_response_error_detail(response)
    if "exist" in detail.lower():
        return True

    loguru.logger.warning(
        f"[MKDIR_FAILED] uri={uri}, status={response.status_code}, detail={compact_fact_text(detail, 120)}"
    )
    return False


async def ensure_namespace_tree(
    uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> bool:
    normalized = normalize_viking_uri(uri)
    segments = split_viking_uri(normalized)
    if len(segments) < 2:
        return False

    current_parent = "viking://resources"
    for index in range(2, len(segments) + 1):
        current_uri = join_viking_uri(segments[:index])
        entries = await list_directory_entries(current_parent, tenant_id=tenant_id, user_id=user_id)
        if any(
            normalize_viking_uri(str(item.get("uri", ""))) == current_uri
            for item in entries
        ):
            current_parent = current_uri
            continue
        if not await mkdir_uri(current_uri, tenant_id=tenant_id, user_id=user_id):
            return False
        current_parent = current_uri
    return True


async def fallback_scan_memories(
    agent: str,
    query: str,
    limit: int,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """当上游搜索结果不稳定时，扫描最近资源做内容匹配降级。"""
    root_uri = build_agent_memory_prefix(agent or "unknown")
    if not await namespace_exists(root_uri, tenant_id=tenant_id, user_id=user_id):
        return []
    leaf_uris = await collect_memory_leaf_uris(
        root_uri,
        tenant_id=tenant_id,
        user_id=user_id,
        max_files=max(limit, config.search_fallback_scan_limit),
    )
    matches: List[Dict[str, Any]] = []

    for uri in leaf_uris:
        content = await read_clean_resource_content(uri, tenant_id=tenant_id, user_id=user_id)
        if not content or not content_matches_query(content, query):
            continue
        matches.append(
            {
                "uri": uri,
                "content": content,
                "abstract": compact_fact_text(content, max_len=240),
                "score": 1.0,
                "category": "resource",
                "level": 2 if PurePosixPath(uri).name.startswith("upload_") else 1,
                "metadata": {"fallback": "content_scan", "agent": agent, "tenant_id": tenant_id},
            }
        )
        if len(matches) >= limit:
            break

    if matches:
        loguru.logger.warning(
            f"[SEARCH_FALLBACK] agent={agent}, query={compact_fact_text(query, 80)}, matches={len(matches)}"
        )
    return matches


async def resolve_leaf_uri(
    root_uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> str:
    """尝试从资源根目录解析真正可读的叶子文件 URI。"""
    try:
        if root_uri.startswith(build_memory_root_prefix()) and not await namespace_exists(
            root_uri,
            tenant_id=tenant_id,
            user_id=user_id,
        ):
            return root_uri
        encoded_uri = quote(root_uri, safe="")
        response = await viking_request(
            "GET",
            f"/api/v1/fs/tree?uri={encoded_uri}",
            operation="resolve_leaf_uri",
            timeout_seconds=config.viking_resolve_timeout_seconds,
            retryable=True,
            tenant_id=tenant_id,
            user_id=user_id,
        )
        if not response.is_success:
            return root_uri
        payload = response.json()
        result = get_nested(payload, "result")
        if not isinstance(result, list):
            return root_uri
        leaf_candidates = [
            item.get("uri")
            for item in result
            if isinstance(item, dict) and not item.get("isDir") and item.get("uri")
        ]
        if leaf_candidates:
            return leaf_candidates[0]
    except Exception:
        pass
    return root_uri


def extract_memory_body(content: Optional[str]) -> Optional[str]:
    """从资源包装文档中提取纯记忆正文。"""
    if not isinstance(content, str):
        return None

    text = content.strip()
    if not text:
        return None

    if text.startswith("# Memory"):
        lines = text.splitlines()
        if lines and lines[0].strip() == "# Memory":
            text = "\n".join(lines[1:]).lstrip()

        for delimiter in ("\n\n---\n", "\n---\n"):
            if delimiter in text:
                text = text.split(delimiter, 1)[0].rstrip()
                break

    return text.strip() or None


def is_derived_resource_uri(uri: str) -> bool:
    """过滤 OpenViking 自动生成的摘要/概览资源，避免污染召回。"""
    if not isinstance(uri, str) or not uri:
        return False

    name = PurePosixPath(uri).name
    return name.startswith(".") or name in {".overview.md", ".abstract.md"}


def normalize_fact_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())


def compact_fact_text(text: str, max_len: int = 180) -> str:
    normalized = normalize_fact_text(text)
    if len(normalized) <= max_len:
        return normalized
    return normalized[: max_len - 3].rstrip() + "..."


def classify_snapshot_fact(text: str) -> str:
    lowered = text.lower()
    if any(pattern in text for pattern in ("是用户", "用户是", "称呼", "叫做")) or "user is" in lowered:
        return "identity"
    if any(pattern in text for pattern in ("项目", "project", "创业", "赚钱系统", "自动化赚钱")):
        return "projects"
    if any(pattern in text for pattern in ("偏好", "期望", "希望", "协作", "风格", "启发", "务实", "高质量")):
        return "preferences"
    if any(pattern in text for pattern in ("决定", "约束", "规则", "必须", "不要", "应当", "以后")):
        return "decisions"
    return "facts"


def should_include_snapshot_fact(text: str) -> bool:
    lowered = text.lower()
    noisy_patterns = [
        "sender (untrusted metadata)",
        "a new session was started",
        "memory adapter should return only",
        "clean readback test",
        "formatting optimization test",
        "codex????",
        "request timeout after",
        "memory/read",
    ]
    if any(pattern in lowered for pattern in noisy_patterns):
        return False

    if "测试" in text and not any(keyword in text for keyword in ("用户", "项目", "偏好", "期望", "协作")):
        return False

    return True


def dedupe_facts(facts: List[str], limit: int) -> List[str]:
    seen = set()
    result: List[str] = []
    for fact in facts:
        normalized = normalize_fact_text(fact).lower()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(compact_fact_text(fact))
        if len(result) >= limit:
            break
    return result


def render_snapshot_markdown(agent: str, grouped_facts: Dict[str, List[str]], source_count: int) -> str:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def render_section(title: str, items: List[str], empty_text: str) -> List[str]:
        lines = [f"### {title}"]
        if items:
            lines.extend(f"- {item}" for item in items)
        else:
            lines.append(f"- {empty_text}")
        lines.append("")
        return lines

    lines: List[str] = [
        "## 启动必读摘要（自动生成）",
        f"- agent: {agent}",
        f"- generated_at: {generated_at}",
        f"- source_memories: {source_count}",
        "",
    ]
    lines.extend(render_section("用户身份与关系", grouped_facts["identity"], "暂无稳定身份事实"))
    lines.extend(render_section("当前项目", grouped_facts["projects"], "暂无高置信项目事实"))
    lines.extend(render_section("协作偏好", grouped_facts["preferences"], "暂无稳定协作偏好"))
    lines.extend(render_section("最近重要决策", grouped_facts["decisions"], "暂无高优先级决策"))
    lines.extend(render_section("其他关键事实", grouped_facts["facts"], "暂无补充关键事实"))
    return "\n".join(lines).strip() + "\n"


async def read_clean_resource_content(
    uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> Optional[str]:
    """按 URI 读取资源正文，并去掉包装元数据。"""
    if not uri:
        return None

    encoded_uri = quote(uri, safe="")
    response = await viking_request(
        "GET",
        f"/api/v1/content/read?uri={encoded_uri}",
        operation="read_clean_resource_content",
        timeout_seconds=config.viking_read_timeout_seconds,
        retryable=True,
        tenant_id=tenant_id,
        user_id=user_id,
    )
    if not response.is_success:
        detail = extract_response_error_detail(response)
        if is_missing_namespace_error(response.status_code, detail):
            loguru.logger.info(f"[READ_MISSING] uri={uri}")
            return None
        loguru.logger.warning(
            f"[READ_FAILED] uri={uri}, status={response.status_code}, detail={compact_fact_text(detail, 120)}"
        )
        return None

    result = response.json()
    if not isinstance(result, dict):
        return None

    return extract_memory_body(result.get("result"))


async def collect_memory_leaf_uris(
    root_uri: str,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
    max_files: int = 200,
) -> List[str]:
    collected: List[str] = []
    seen_dirs = set()
    stack = [root_uri]

    while stack and len(collected) < max_files:
        current = stack.pop()
        if current in seen_dirs:
            continue
        seen_dirs.add(current)

        for item in await list_directory_entries(current, tenant_id=tenant_id, user_id=user_id):
            uri = item.get("uri")
            if not isinstance(uri, str) or not uri:
                continue
            name = PurePosixPath(uri).name
            if item.get("isDir"):
                if not name.startswith("."):
                    stack.append(uri)
                continue
            if is_derived_resource_uri(uri):
                continue
            if name.startswith("upload_") and uri not in collected:
                collected.append(uri)
                if len(collected) >= max_files:
                    break

    return collected


def filter_expired_memories(memories: list, current_time: int = None) -> list:
    """
    过滤过期记忆
    在 read 接口调用
    """
    if current_time is None:
        current_time = int(datetime.now().timestamp())

    filtered = []
    for memory in memories:
        metadata = memory.get("metadata", {})
        expire_at = metadata.get("expire_at", -1)

        # -1 表示永久不过期
        if expire_at == -1:
            filtered.append(memory)
        # 0 表示已过期
        elif expire_at == 0:
            continue
        # 检查是否过期
        elif expire_at > current_time:
            filtered.append(memory)
        # 已过期
        else:
            loguru.logger.debug(f"[EXPIRED] memory_id={memory.get('id', 'unknown')}")

    return filtered


# ==================== 路由 ====================

@app.get("/")
async def root():
    """根路径"""
    return {
        "service": "Memory Adapter v2.2",
        "version": "2.2.0",
        "viking_url": config.viking_url,
        "support_schema_version": SUPPORT_SCHEMA_VERSION,
        "dedup_stats": get_dedup_cache().get_stats(),
        "rate_limit": {
            "max_per_minute": config.rate_limit_per_minute,
            "current": _rate_limiter.get_current_count()
        }
    }


@app.get("/health")
async def health():
    """健康检查"""
    viking_healthy = False
    health_detail = {"status_code": None, "error": None}
    try:
        response = await viking_request(
            "GET",
            "/health",
            operation="health_check",
            timeout_seconds=config.viking_health_timeout_seconds,
            retryable=True,
        )
        viking_healthy = response.status_code == 200
        health_detail["status_code"] = response.status_code
    except Exception as exc:
        health_detail["error"] = str(exc)

    return {
        "status": "healthy" if viking_healthy else "degraded",
        "viking_url": config.viking_url,
        "viking_connected": viking_healthy,
        "namespace_root": build_memory_root_prefix(),
        "timeout_profile": {
            "connect_seconds": config.viking_connect_timeout_seconds,
            "health_seconds": config.viking_health_timeout_seconds,
            "search_seconds": config.viking_search_timeout_seconds,
            "read_seconds": config.viking_read_timeout_seconds,
            "delete_seconds": config.viking_delete_timeout_seconds,
            "snapshot_seconds": config.viking_snapshot_timeout_seconds,
            "upload_seconds": config.viking_upload_timeout_seconds,
            "commit_seconds": config.viking_commit_timeout_seconds,
            "resolve_seconds": config.viking_resolve_timeout_seconds,
            "retry_attempts": config.viking_retry_attempts,
            "retry_backoff_seconds": config.viking_retry_backoff_seconds,
            "slow_request_threshold_ms": config.slow_request_threshold_ms,
        },
        "path_policy": {
            "agent_segment_sanitized": True,
            "namespace_prepare_on_write": True,
            "missing_namespace_returns_empty": True,
        },
        "error_policy": {
            "schema_version": SUPPORT_SCHEMA_VERSION,
            "request_id_header": "X-Request-ID",
            "catalog_endpoint": "/support/error-codes",
            "structured_http_errors": True,
            "write_error_fields": ["reason", "error_code", "request_id", "support"],
        },
        "viking_health_detail": health_detail,
        "dedup_stats": get_dedup_cache().get_stats(),
        "rate_limit": {
            "enabled": config.enable_rate_limit,
            "max_per_minute": config.rate_limit_per_minute,
            "current": _rate_limiter.get_current_count()
        }
    }


@app.get("/support/error-codes")
async def support_error_codes():
    """售后错误码目录。"""
    return {
        "schema_version": SUPPORT_SCHEMA_VERSION,
        "count": len(SUPPORT_ERROR_CATALOG),
        "error_codes": [
            {
                "code": code,
                "category": meta["category"],
                "severity": meta["severity"],
                "retryable": meta["retryable"],
                "suggested_action": meta["suggested_action"],
            }
            for code, meta in sorted(SUPPORT_ERROR_CATALOG.items())
        ],
    }


@app.post("/memory/write", response_model=MemoryResponse)
async def write_memory(request: MemoryRequest, http_request: Request):
    """
    主接口：写入记忆

    处理流程：
    1. 标准化 - 统一数据格式
    2. 过滤 - 判断是否需要存储
    3. 去重 - 检查内容是否重复
    4. 限流 - 检查写入频率
    5. 路由 - 决定记忆类型和等级（含失败经验检测）
    6. 转换 - 转换为 OpenViking 格式（含 expire_at）
    7. 转发 - 发送到 OpenViking
    """
    loguru.logger.info(f"[WRITE] Received from agent={request.agent}, type={request.type}, len={len(request.content)}")

    # ========== 1. 标准化 ==========
    data = normalize(request.dict())

    # ========== 2. 过滤 ==========
    should_store_result, reason = should_store(request.content, request.type)
    if not should_store_result:
        log_filtered(reason, request.content)
        return MemoryResponse(
            status="skipped",
            reason=reason,
            request_id=get_request_id(http_request),
        )

    # ========== 3. 去重 ==========
    if config.enable_deduplication:
        is_dup, content_id = check_duplicate(request.content)
        if is_dup:
            loguru.logger.info(f"[DUPLICATE] content_id={content_id[:8]}...")
            return MemoryResponse(
                status="duplicate",
                reason="content_already_exists",
                memory_id=content_id,
                request_id=get_request_id(http_request),
            )
    else:
        content_id = ""

    # ========== 4. 限流 ==========
    if config.enable_rate_limit:
        if not _rate_limiter.is_allowed():
            current = _rate_limiter.get_current_count()
            loguru.logger.warning(f"[RATE_LIMITED] current={current}, limit={config.rate_limit_per_minute}")
            return MemoryResponse(
                status="rate_limited",
                reason=f"rate_limit_exceeded: {current}/{config.rate_limit_per_minute}",
                request_id=get_request_id(http_request),
            )

    # ========== 5. 路由（含失败经验检测） ==========
    # 检测失败内容
    is_failure, failure_type = detect_failure_content(request.content)

    # 如果是失败内容，更新 type
    if is_failure:
        data["type"] = failure_type
        loguru.logger.info(f"[FAILURE_DETECTED] content contains error/failure, type={failure_type}")

    memory_type, memory_level, score = route_memory_type_and_level(request.content, data)
    loguru.logger.info(f"[ROUTE] type={memory_type}, level={memory_level}, score={score}")

    # 计算过期时间
    expire_at = calculate_expire_at(memory_level, request.timestamp)

    # ========== 6. 转换 ==========
    viking_payload = to_viking_format(
        data,
        memory_type=memory_type,
        memory_level=memory_level,
        score=score,
        content_id=content_id
    )
    resource_uri = build_memory_resource_uri(request.agent, memory_type)
    resource_markdown = (
        f"# Memory\n\n"
        f"{request.content.strip()}\n\n"
        f"---\n"
        f"- agent: {request.agent}\n"
        f"- type: {data.get('type', request.type)}\n"
        f"- memory_type: {memory_type}\n"
        f"- memory_level: {memory_level}\n"
        f"- score: {score}\n"
        f"- expire_at: {expire_at}\n"
        f"- content_id: {content_id}\n"
        f"- adapter_version: 2.2.0\n"
    )

    # ========== 7. 转发 ==========
    try:
        if not await ensure_namespace_tree(build_memory_type_prefix(request.agent, memory_type)):
            return build_memory_error_response(
                http_request,
                "ADAPTER_NAMESPACE_PREPARE_FAILED",
                "viking_namespace_prepare_failed",
                operation="write_memory",
                detail="Failed to prepare the target agent namespace before commit.",
            )

        files = {
            "file": ("memory.md", resource_markdown.encode("utf-8"), "text/markdown")
        }
        upload_response = await viking_request(
            "POST",
            "/api/v1/resources/temp_upload",
            operation="write_temp_upload",
            timeout_seconds=config.viking_upload_timeout_seconds,
            retryable=False,
            files=files,
        )
        if not upload_response.is_success:
            log_error("Viking upload error", f"status={upload_response.status_code}")
            return build_memory_error_response(
                http_request,
                "ADAPTER_VIKING_UPLOAD_FAILED",
                f"viking_upload_error:{upload_response.status_code}",
                operation="write_temp_upload",
                detail=f"OpenViking temp upload failed with status {upload_response.status_code}.",
                upstream_status=upload_response.status_code,
            )

        upload_result = upload_response.json()
        temp_path = get_nested(upload_result, "result.temp_path")
        if not temp_path:
            log_error("Viking upload error", "missing temp_path")
            return build_memory_error_response(
                http_request,
                "ADAPTER_VIKING_UPLOAD_FAILED",
                "viking_upload_missing_temp_path",
                operation="write_temp_upload",
                detail="OpenViking temp upload returned without temp_path.",
            )

        resource_request = {
            "temp_path": temp_path,
            "to": resource_uri,
            "reason": f"memory-adapter:{memory_type}",
            "instruction": "Store this text as retrievable long-term memory for the agent.",
            "wait": True,
        }
        response = await viking_request(
            "POST",
            "/api/v1/resources",
            operation="write_commit_resource",
            timeout_seconds=config.viking_commit_timeout_seconds,
            retryable=False,
            json=resource_request,
        )

        if response.is_success:
            if config.enable_deduplication:
                add_to_dedup(request.content)

            viking_result = response.json()
            parsed = parse_viking_response(viking_result)
            root_uri = get_nested(viking_result, "result.root_uri") or resource_uri
            stored_uri = await resolve_leaf_uri(root_uri)

            log_stored(request.agent, memory_type, memory_level, score, is_failure)

            return MemoryResponse(
                status="stored",
                memory_id=stored_uri,
                uri=stored_uri,
                memory_type=memory_type,
                memory_level=memory_level,
                memory_expire_at=expire_at,
                score=score,
                is_failure=is_failure,
                request_id=get_request_id(http_request),
            )

        log_error(f"Viking error", f"status={response.status_code} body={response.text}")
        return build_memory_error_response(
            http_request,
            "ADAPTER_VIKING_COMMIT_FAILED",
            f"viking_error:{response.status_code}",
            operation="write_commit_resource",
            detail=f"OpenViking resource commit failed with status {response.status_code}.",
            upstream_status=response.status_code,
        )

    except httpx.ConnectError as e:
        log_error("OpenViking unavailable", str(e))
        return build_memory_error_response(
            http_request,
            "ADAPTER_VIKING_UNAVAILABLE",
            "viking_unavailable",
            operation="write_memory",
            detail=str(e),
        )
    except httpx.TimeoutException as e:
        log_error("OpenViking timeout", f"{type(e).__name__}: {e}")
        return build_memory_error_response(
            http_request,
            "ADAPTER_VIKING_TIMEOUT",
            "viking_timeout",
            operation="write_memory",
            detail=f"{type(e).__name__}: {e}",
        )
    except Exception as e:
        import traceback
        log_error("Unexpected error", f"{str(e)}\nStack trace:\n{traceback.format_exc()}")
        return build_memory_error_response(
            http_request,
            "ADAPTER_INTERNAL_ERROR",
            f"internal_error:{str(e)}",
            operation="write_memory",
            detail=str(e),
            suggested_action="记录 request_id 并检查 Adapter 运行日志中的对应堆栈。",
        )


@app.post("/memory/search")
async def search_memory(request: RetrieveRequest, http_request: Request):
    """
    搜索记忆，返回与 OpenClaw 插件兼容的 memories[] 结构。

    优先尝试当前 OpenViking 自定义 /retrieve；若失败则回退到官方 /api/v1/search/find。
    """
    if not request.query:
        raise_support_api_error(
            http_request,
            400,
            "ADAPTER_BAD_REQUEST",
            "query is required",
            operation="search_memory",
            detail="query is required",
            retryable=False,
        )

    tenant_id, user_id = resolve_tenant_identity(http_request)

    payload: Dict[str, Any] = {
        "query": request.query,
        "limit": request.limit,
    }
    if request.agent:
        payload["agent"] = request.agent
    if request.memory_type:
        payload["memory_type"] = request.memory_type
    if request.memory_level:
        payload["memory_level"] = request.memory_level
    if request.scoreThreshold is not None:
        payload["score_threshold"] = request.scoreThreshold

    raw_result: Any = None
    last_error = ""

    fallback_payload: Dict[str, Any] = {
        "query": request.query,
        "limit": request.limit,
        "target_uri": build_agent_memory_prefix(request.agent or "unknown"),
    }
    if request.scoreThreshold is not None:
        fallback_payload["score_threshold"] = request.scoreThreshold

    if request.agent and not await namespace_exists(
        build_agent_memory_prefix(request.agent),
        tenant_id=tenant_id,
        user_id=user_id,
    ):
        return {
            "memories": [],
            "total": 0,
        }

    try:
        response = await viking_request(
            "POST",
            "/api/v1/search/find",
            operation="search_memory",
            timeout_seconds=config.viking_search_timeout_seconds,
            retryable=True,
            tenant_id=tenant_id,
            user_id=user_id,
            json=fallback_payload,
        )
        if response.is_success:
            raw_result = response.json()
        else:
            last_error = f"/api/v1/search/find status={response.status_code}"
    except Exception as exc:
        last_error = f"/api/v1/search/find error={exc}"

    if raw_result is None:
        log_error("Error searching memory", last_error)
        raise_support_api_error(
            http_request,
            502,
            "ADAPTER_SEARCH_FAILED",
            "Search request failed",
            operation="search_memory",
            detail=last_error or "search_failed",
            retryable=True,
        )

    memories = [
        to_plugin_memory(item)
        for item in extract_memory_items(raw_result)
        if not is_derived_resource_uri(
            item.get("uri")
            or item.get("id")
            or (item.get("metadata", {}) if isinstance(item.get("metadata"), dict) else {}).get("uri")
            or ""
        )
    ]

    if request.agent:
        memories = [
            item for item in memories
            if not item.get("metadata") or item["metadata"].get("agent") in (None, request.agent)
        ]
    if request.memory_type:
        memories = [
            item for item in memories
            if item.get("category") == request.memory_type
            or item.get("metadata", {}).get("memory_type") == request.memory_type
        ]
    if request.memory_level:
        requested_level = map_memory_level(request.memory_level)
        if requested_level is not None:
            memories = [item for item in memories if item.get("level") == requested_level]

    if not request.include_expired:
        current_time = int(datetime.now().timestamp())
        memories = [
            item for item in memories
            if (
                item.get("metadata", {}).get("expire_at", -1) == -1
                or item.get("metadata", {}).get("expire_at", -1) > current_time
            )
        ]

    for item in memories:
        uri = item.get("uri")
        level = item.get("level")
        if not isinstance(uri, str) or not uri:
            continue
        if level == 2 or PurePosixPath(uri).name.startswith("upload_"):
            clean_content = await read_clean_resource_content(uri, tenant_id=tenant_id, user_id=user_id)
            if clean_content:
                item["content"] = clean_content
                item["abstract"] = clean_content

    if request.agent and request.query:
        already_matched = any(
            content_matches_query(str(item.get("content", "")), request.query)
            or content_matches_query(str(item.get("abstract", "")), request.query)
            for item in memories
        )
        if not already_matched:
            fallback_matches = await fallback_scan_memories(
                request.agent,
                request.query,
                request.limit,
                tenant_id=tenant_id,
                user_id=user_id,
            )
            existing_uris = {item.get("uri") for item in memories}
            for item in fallback_matches:
                if item.get("uri") not in existing_uris:
                    memories.insert(0, item)

    return {
        "memories": memories[: request.limit],
        "total": len(memories),
    }


@app.post("/memory/read")
async def read_memory(request: RetrieveRequest, http_request: Request):
    """
    读取记忆内容。

    优先按 uri 读取单条内容；如果没有 uri，则回退到旧的 query 检索行为。
    """
    try:
        tenant_id, user_id = resolve_tenant_identity(http_request)
        if request.uri:
            parsed_content = await read_clean_resource_content(request.uri, tenant_id=tenant_id, user_id=user_id)
            if parsed_content is not None:
                return {"content": parsed_content}
            return {"content": None}

        if not request.query:
            raise_support_api_error(
                http_request,
                400,
                "ADAPTER_BAD_REQUEST",
                "uri or query is required",
                operation="read_memory",
                detail="uri or query is required",
                retryable=False,
            )

        if request.agent and not await namespace_exists(
            build_agent_memory_prefix(request.agent),
            tenant_id=tenant_id,
            user_id=user_id,
        ):
            return {"memories": [], "total": 0}

        payload = {
            "query": request.query,
            "limit": request.limit
        }

        if request.agent:
            payload["agent"] = request.agent
        if request.memory_type:
            payload["memory_type"] = request.memory_type
        if request.memory_level:
            payload["memory_level"] = request.memory_level

        response = await viking_request(
            "POST",
            "/retrieve",
            operation="read_memory_query",
            timeout_seconds=config.viking_read_timeout_seconds,
            retryable=True,
            tenant_id=tenant_id,
            user_id=user_id,
            json=payload,
        )
        if not response.is_success:
            detail = extract_response_error_detail(response)
            raise_support_api_error(
                http_request,
                502,
                "ADAPTER_READ_FAILED",
                "Read request failed",
                operation="read_memory_query",
                detail=detail or "read_failed",
                upstream_status=response.status_code,
                retryable=True,
            )

        if not request.include_expired:
            result = response.json()
            if isinstance(result, dict) and "memories" in result:
                result["memories"] = filter_expired_memories(result["memories"])
                result["total"] = len(result["memories"])
            return result

        return response.json()
    except HTTPException:
        raise
    except SupportAPIError:
        raise
    except Exception as e:
        log_error("Error reading memory", str(e))
        raise_support_api_error(
            http_request,
            500,
            "ADAPTER_READ_FAILED",
            "Read request failed",
            operation="read_memory",
            detail=str(e),
            retryable=True,
        )


@app.post("/memory/delete")
async def delete_memory(request: DeleteRequest, http_request: Request):
    """按 URI 删除记忆。"""
    try:
        tenant_id, user_id = resolve_tenant_identity(http_request)
        encoded_uri = quote(request.uri, safe="")
        response = await viking_request(
            "DELETE",
            f"/api/v1/fs?uri={encoded_uri}",
            operation="delete_memory",
            timeout_seconds=config.viking_delete_timeout_seconds,
            retryable=True,
            tenant_id=tenant_id,
            user_id=user_id,
        )
        if response.is_success:
            return {"success": True, "uri": request.uri, "request_id": get_request_id(http_request)}
        detail = extract_response_error_detail(response)
        if is_missing_namespace_error(response.status_code, detail):
            return {
                "success": False,
                "uri": request.uri,
                "status": response.status_code,
                "reason": "not_found",
                "request_id": get_request_id(http_request),
                "error_code": "ADAPTER_DELETE_FAILED",
                "support": build_support_payload(
                    http_request,
                    "ADAPTER_DELETE_FAILED",
                    "Delete target was not found",
                    operation="delete_memory",
                    detail=detail or "not_found",
                    upstream_status=response.status_code,
                    retryable=False,
                )["support"],
            }
        return {
            "success": False,
            "uri": request.uri,
            "status": response.status_code,
            "reason": detail or "delete_failed",
            "request_id": get_request_id(http_request),
            "error_code": "ADAPTER_DELETE_FAILED",
            "support": build_support_payload(
                http_request,
                "ADAPTER_DELETE_FAILED",
                "Delete request failed",
                operation="delete_memory",
                detail=detail or "delete_failed",
                upstream_status=response.status_code,
            )["support"],
        }
    except HTTPException:
        raise
    except SupportAPIError:
        raise
    except Exception as e:
        log_error("Error deleting memory", str(e))
        raise_support_api_error(
            http_request,
            500,
            "ADAPTER_DELETE_FAILED",
            "Delete request failed",
            operation="delete_memory",
            detail=str(e),
            retryable=True,
        )


@app.post("/memory/snapshot")
async def build_memory_snapshot(request: SnapshotRequest, http_request: Request):
    """
    从 OpenViking 主库生成 MEMORY.md 自动摘要区。
    """
    try:
        tenant_id, user_id = resolve_tenant_identity(http_request)
        root_uri = build_agent_memory_prefix(request.agent)
        if not await namespace_exists(root_uri, tenant_id=tenant_id, user_id=user_id):
            markdown = render_snapshot_markdown(
                request.agent,
                {
                    "identity": [],
                    "projects": [],
                    "preferences": [],
                    "decisions": [],
                    "facts": [],
                },
                0,
            )
            return {
                "agent": request.agent,
                "generatedAt": datetime.now().isoformat(),
                "sourceCount": 0,
                "markdown": markdown,
                "sections": {"identity": 0, "projects": 0, "preferences": 0, "decisions": 0, "facts": 0},
                "request_id": get_request_id(http_request),
            }
        leaf_uris = await collect_memory_leaf_uris(
            root_uri,
            tenant_id=tenant_id,
            user_id=user_id,
            max_files=max(20, request.limit),
        )

        grouped: Dict[str, List[str]] = {
            "identity": [],
            "projects": [],
            "preferences": [],
            "decisions": [],
            "facts": [],
        }

        for uri in leaf_uris:
            content = await read_clean_resource_content(uri, tenant_id=tenant_id, user_id=user_id)
            if not content:
                continue
            if not should_include_snapshot_fact(content):
                continue
            group = classify_snapshot_fact(content)
            grouped[group].append(content)

        deduped = {
            "identity": dedupe_facts(grouped["identity"], 6),
            "projects": dedupe_facts(grouped["projects"], 8),
            "preferences": dedupe_facts(grouped["preferences"], 8),
            "decisions": dedupe_facts(grouped["decisions"], 8),
            "facts": dedupe_facts(grouped["facts"], 10),
        }

        markdown = render_snapshot_markdown(request.agent, deduped, len(leaf_uris))

        return {
            "agent": request.agent,
            "generatedAt": datetime.now().isoformat(),
            "sourceCount": len(leaf_uris),
            "markdown": markdown,
            "sections": {key: len(value) for key, value in deduped.items()},
            "request_id": get_request_id(http_request),
        }
    except HTTPException:
        raise
    except SupportAPIError:
        raise
    except Exception as e:
        log_error("Error building memory snapshot", str(e))
        raise_support_api_error(
            http_request,
            500,
            "ADAPTER_SNAPSHOT_FAILED",
            "Snapshot generation failed",
            operation="build_memory_snapshot",
            detail=str(e),
            retryable=True,
        )


@app.get("/memory/types")
async def get_memory_types():
    """获取记忆类型和等级配置"""
    return {
        "memory_types": ["long_term", "short_term"],
        "memory_levels": {
            "L0": "垃圾/不存",
            "L1": "短期缓存 (7天)",
            "L2": "经验记忆 (30天)",
            "L3": "核心知识 (永久)"
        },
        "score_rules": config.route_score_rules,
        "long_term_threshold": config.long_term_threshold,
        "exclude_types": config.exclude_types,
        "ttl_config": {
            "L1": "7 days",
            "L2": "30 days",
            "L3": "permanent"
        },
        "failure_detection": {
            "enabled": True,
            "keywords": ["错误", "error", "失败", "fail", "异常", "exception"]
        }
    }


@app.get("/memory/dedup/stats")
async def get_dedup_stats():
    """获取去重缓存状态"""
    return get_dedup_cache().get_stats()


@app.get("/memory/rate_limit/stats")
async def get_rate_limit_stats():
    """获取限流状态"""
    return {
        "enabled": config.enable_rate_limit,
        "max_per_minute": config.rate_limit_per_minute,
        "current": _rate_limiter.get_current_count()
    }


# ==================== V2 Platform Endpoints ====================

@app.post("/memory/query", response_model=MemoryQueryResponse)
async def query_memory_v2(request: MemoryQueryRequest, http_request: Request):
    """
    V2: Unified memory query interface with Token Savings Meter.

    This endpoint wraps the existing /memory/search with optimization
    and token savings metering.
    """
    access = resolve_query_access(
        http_request,
        requested_tenant=request.tenant,
        requested_user=request.user,
        registry_path=config.omnimemora_access_registry_path,
        require_key=config.omnimemora_require_api_key_for_v2,
        registry_sync=config.registry_sync.model_dump() if config.registry_sync else None,
    )
    http_request.state.omnimemora_access = access.to_dict()

    # --- Hard quota enforcement for SaaS-key-authenticated tenants only ---
    # legacy_body auth mode is NOT hard-blocked in this slice (per acceptance criteria)
    if access.auth_mode == "omnimemora_key":
        registry_entry = get_tenant_registry_entry(
            config.omnimemora_access_registry_path,
            access.tenant_id,
        )
        quota_result = check_quota_enforcement(access.tenant_id, registry_entry)
        if quota_result.quota_exceeded:
            loguru.logger.warning(
                f"[QUOTA_EXCEEDED] tenant={access.tenant_id}, "
                f"current_usage={quota_result.current_usage}, "
                f"monthly_quota={quota_result.monthly_quota}"
            )
            raise_support_api_error(
                http_request,
                429,
                "ADAPTER_QUOTA_EXCEEDED",
                f"Monthly token quota exceeded ({quota_result.current_usage}/{quota_result.monthly_quota})",
                operation="memory_query_quota_check",
                detail=(
                    f"Tenant {access.tenant_id} has exceeded monthly token quota. "
                    f"Current usage: {quota_result.current_usage} tokens. "
                    f"Monthly quota: {quota_result.monthly_quota} tokens. "
                    f"Upgrade plan or wait for billing cycle reset."
                ),
                retryable=False,
                extra={
                    "tenant_id": access.tenant_id,
                    "current_usage": quota_result.current_usage,
                    "monthly_quota": quota_result.monthly_quota,
                    "quota_status": quota_result.quota_status,
                },
            )

    request_id = f"req-{uuid4().hex[:8]}"
    loguru.logger.info(
        f"[QUERY_V2] request_id={request_id}, tenant={access.tenant_id}, auth_mode={access.auth_mode}, query={request.query[:50]}..."
    )

    # Parse options with defaults
    options = request.options or {}
    max_local_cards = options.get("max_local_cards", 4)
    remote_limit = options.get("remote_limit", 1)
    packing_enabled = options.get("enable_packing", True)

    # Step 1: Use existing /memory/search internally
    retrieve_req = RetrieveRequest(
        query=request.query,
        agent=request.agent,
        limit=max_local_cards * 2,
        scoreThreshold=0.01
    )

    http_request.state.v2_tenant_override = access.tenant_id
    http_request.state.v2_user_override = access.user_id
    try:
        search_result = await search_memory(retrieve_req, http_request)
    finally:
        http_request.state.v2_tenant_override = None
        http_request.state.v2_user_override = None
    memories = search_result.get("memories", [])[:max_local_cards]

    # Format selected memories for response
    selected_memories = []
    for idx, mem in enumerate(memories):
        selected_memories.append({
            "id": mem.get("uri", f"mem-{idx:03d}"),
            "type": mem.get("category", "memory"),
            "score": mem.get("score", 0.5),
            "content": mem.get("content", mem.get("abstract", "")),
            "source": "local"
        })

    # Step 2: Build packed context
    packed_context = build_packed_context(selected_memories) if packing_enabled else ""

    # Step 3: Generate Token Savings Meter artifact
    client = (request.context or {}).get("client")
    if not client:
        client = "omnimemora-api" if access.key_present else "openclaw"
    meter = generate_meter_artifact(
        request_id=request_id,
        tenant=access.tenant_id,
        user=access.user_id,
        agent=request.agent,
        client=client,
        query=request.query,
        selected_memories=selected_memories,
        remote_candidates_considered=16,
        local_cards_used=len(selected_memories),
        packing_enabled=packing_enabled,
    )

    # Store meter artifact (in-memory for prototype)
    store_meter(meter)

    # Build explanation
    explanation = {
        "local_cards_used": len(selected_memories),
        "remote_candidates_skipped": 16,
        "skip_remote_reason": "local-first coverage satisfied",
        "packing_enabled": packing_enabled,
        "abstract_preferred": False,
        "auth_mode": access.auth_mode,
        "tenant_status": access.status,
    }

    return MemoryQueryResponse(
        request_id=request_id,
        selected_memories=selected_memories,
        packed_context=packed_context,
        memory_tokens_injected=meter.actual_tokens_estimate,
        tokens_saved_estimate=meter.saved_tokens_estimate,
        savings_ratio=meter.savings_ratio,
        explanation=explanation,
        meter_artifact={"$ref": f"/requests/{request_id}/meter"}
    )


@app.get("/usage/token-savings")
async def get_token_savings(
    tenant: str,
    agent: Optional[str] = None,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None
):
    """Get aggregated token savings for a tenant/agent."""
    from datetime import datetime

    start_dt = datetime.fromisoformat(start_time) if start_time else None
    end_dt = datetime.fromisoformat(end_time) if end_time else None

    usage = get_tenant_usage(tenant, start_dt, end_dt)
    registry_entry = get_tenant_registry_entry(config.omnimemora_access_registry_path, tenant)
    monthly_quota_tokens = None
    plan = None
    status = None
    quota_status = "untracked"
    if registry_entry:
        plan = registry_entry.get("plan")
        status = registry_entry.get("status")
        raw_quota = registry_entry.get("monthly_quota_tokens")
        if raw_quota not in (None, ""):
            try:
                monthly_quota_tokens = int(raw_quota)
            except (TypeError, ValueError):
                monthly_quota_tokens = None

    current_period_usage = usage.get("current_period_usage", 0)
    if monthly_quota_tokens is not None:
        quota_status = "over_quota" if current_period_usage > monthly_quota_tokens else "within_quota"

    if agent:
        usage["by_agent"] = [a for a in usage.get("by_agent", []) if a["agent"] == agent]

    usage["plan"] = plan
    usage["status"] = status
    usage["monthly_quota_tokens"] = monthly_quota_tokens
    usage["quota_status"] = quota_status
    return usage


@app.get("/usage/token-savings/trend")
async def get_token_savings_trend(tenant: str, agent: Optional[str] = None, days: int = 7):
    """Get token savings trend data for the last N days."""
    trend_data = get_trend_data(tenant, days)
    trend_data["agent"] = agent
    return trend_data


@app.get("/requests/{request_id}/meter")
async def get_request_meter(request_id: str):
    """Get full meter artifact for a specific request."""
    meter = get_meter(request_id)
    if not meter:
        raise HTTPException(status_code=404, detail=f"Meter not found for request_id={request_id}")
    return meter.to_dict()


# ==================== Trial Provisioning (Protected Admin) ====================

from app.access import hash_api_key, atomic_write_registry, load_registry


class TrialProvisionRequest(BaseModel):
    """Request body for trial provisioning endpoint."""
    contact_email: Optional[str] = None
    display_name: Optional[str] = None
    source: Optional[str] = None


class TrialProvisionResponse(BaseModel):
    """Response body for successful trial provisioning."""
    tenant_id: str
    api_key: str          # plaintext — shown only once here
    plan: str
    status: str
    monthly_quota_tokens: int
    trial_expires_at: Optional[int] = None
    created_at: str


@app.post("/api/admin/trials/provision", response_model=TrialProvisionResponse)
async def provision_trial(request: TrialProvisionRequest, http_request: Request):
    """
    Minimal protected trial provisioning endpoint.

    Protected by: OMNIMEMORA_ADMIN_API_TOKEN sent as X-OmniMemora-Admin-Token header.

    Responsibilities:
    - Validate admin token
    - Generate tenant_id and a one-time plaintext API key
    - Write api_key_hash (never plaintext) to tenant_access_registry.json
    - Default plan=starter, status=active, quota from config
    - Return plaintext API key once (never stored or retrievable after)
    """
    # ---- Admin token check ----
    admin_token = http_request.headers.get("X-OmniMemora-Admin-Token", "")
    if not admin_token:
        raise HTTPException(status_code=401, detail="Missing X-OmniMemora-Admin-Token header.")
    if admin_token != config.omnimemora_admin_api_token:
        raise HTTPException(status_code=403, detail="Invalid admin token.")

    # ---- Generate identifiers ----
    tenant_id = f"trial-{uuid4().hex[:12]}"
    raw_api_key = f"omni-{uuid4().hex}-{uuid4().hex[:8]}"
    api_key_hash = hash_api_key(raw_api_key)
    token_id = f"tk-{uuid4().hex[:12]}"

    # ---- Build tenant entry (hash only, never plaintext) ----
    now_ts = int(datetime.now().timestamp())
    trial_seconds = config.omnimemora_trial_days * 86400
    trial_expires_at = now_ts + trial_seconds if config.omnimemora_trial_days > 0 else None

    now_iso = datetime.now().isoformat()
    new_entry: Dict[str, Any] = {
        "tenant_id": tenant_id,
        "api_key_hash": api_key_hash,
        "token_id": token_id,
        "plan": "starter",
        "status": "active",
        "monthly_quota_tokens": config.omnimemora_trial_quota_tokens,
        "default_user": "trial-user",
        "trial_expires_at": trial_expires_at,
        "created_at": now_iso,
        "source": request.source or "trial-provisioning",
    }
    if request.contact_email:
        new_entry["contact_email"] = request.contact_email
    if request.display_name:
        new_entry["display_name"] = request.display_name

    # ---- Atomic write to registry ----
    registry = load_registry(config.omnimemora_access_registry_path)
    registry.append(new_entry)
    atomic_write_registry(config.omnimemora_access_registry_path, registry)

    loguru.logger.info(
        f"[TRIAL_PROVISIONED] tenant={tenant_id}, plan=starter, quota={config.omnimemora_trial_quota_tokens}, "
        f"expires_at={trial_expires_at}, source={request.source or 'direct'}"
    )

    return TrialProvisionResponse(
        tenant_id=tenant_id,
        api_key=raw_api_key,
        plan="starter",
        status="active",
        monthly_quota_tokens=config.omnimemora_trial_quota_tokens,
        trial_expires_at=trial_expires_at,
        created_at=now_iso,
    )


# ==================== Internal Service Endpoints ====================

class InternalTrialQueryRequest(BaseModel):
    """Request body for internal trial query proxy."""
    tenant: str
    user: str
    agent: str = "omnimemora-trial"
    query: str
    limit: int = 10
    context: Optional[Dict[str, Any]] = None
    options: Optional[Dict[str, Any]] = None


class InternalTrialQueryResponse(BaseModel):
    """Response shape returned to Cloudflare trial/query proxy."""
    selected_memories: List[Dict[str, Any]]
    packed_context: str
    memory_tokens_injected: int
    tokens_saved_estimate: int
    savings_ratio: float
    explanation: Dict[str, Any]
    meter_artifact: Optional[Dict[str, Any]] = None


@app.post("/internal/trial-query", response_model=InternalTrialQueryResponse)
async def internal_trial_query(request: InternalTrialQueryRequest, http_request: Request):
    """
    Internal trial query endpoint — called ONLY by Cloudflare Pages Functions
    (query.ts) after it has already validated the API key against D1.

    Trust is established via X-Internal-Token header matching
    OMNIMEMORA_INTERNAL_API_TOKEN env var.

    This endpoint bypasses the normal OmniMemora API key auth flow and
    uses the tenant context passed directly from the validated Cloudflare layer.
    """
    import os as _os

    # ---- Verify internal service token ----
    internal_token = http_request.headers.get("X-Internal-Token", "")
    expected_token = _os.getenv("OMNIMEMORA_INTERNAL_API_TOKEN", "")
    if not expected_token:
        loguru.logger.warning("[INTERNAL] OMNIMEMORA_INTERNAL_API_TOKEN not set — rejecting internal call")
        raise HTTPException(status_code=500, detail="Internal API token not configured on adapter.")
    if not internal_token or internal_token != expected_token:
        loguru.logger.warning(f"[INTERNAL] Invalid internal token from {http_request.client}")
        raise HTTPException(status_code=403, detail="Invalid internal service token.")

    # ---- Also verify tenant came from X-OmniMemora-Tenant header ----
    validated_tenant = http_request.headers.get("X-OmniMemora-Tenant", "")
    if not validated_tenant:
        raise HTTPException(status_code=400, detail="Missing X-OmniMemora-Tenant header.")
    if validated_tenant != request.tenant:
        raise HTTPException(status_code=400, detail="Tenant mismatch between header and body.")

    loguru.logger.info(
        f"[INTERNAL_TRIAL_QUERY] tenant={request.tenant}, user={request.user}, "
        f"agent={request.agent}, query={request.query[:50]}..."
    )

    # ---- Use the existing V2 query machinery internally ----
    # We manually set up state so search_memory and generate_meter_artifact work.
    http_request.state.v2_tenant_override = request.tenant
    http_request.state.v2_user_override = request.user

    try:
        # Build a fake "access" for quota check (bypass real auth)
        # Use the same quota enforcement logic but skip the API key check.
        registry_entry = get_tenant_registry_entry(
            config.omnimemora_access_registry_path,
            request.tenant,
        )
        quota_result = check_quota_enforcement(request.tenant, registry_entry)
        if quota_result.quota_exceeded:
            raise_support_api_error(
                http_request,
                429,
                "ADAPTER_QUOTA_EXCEEDED",
                f"Monthly token quota exceeded ({quota_result.current_usage}/{quota_result.monthly_quota})",
                operation="internal_trial_query_quota",
                detail=(
                    f"Tenant {request.tenant} has exceeded monthly token quota. "
                    f"Current usage: {quota_result.current_usage} tokens. "
                    f"Monthly quota: {quota_result.monthly_quota} tokens."
                ),
                retryable=False,
                extra={
                    "tenant_id": request.tenant,
                    "current_usage": quota_result.current_usage,
                    "monthly_quota": quota_result.monthly_quota,
                    "quota_status": quota_result.quota_status,
                },
            )

        # Use the existing search_memory logic (same as V2 /memory/query)
        options = request.options or {}
        max_local_cards = options.get("max_local_cards", 4)
        packing_enabled = options.get("enable_packing", True)

        retrieve_req = RetrieveRequest(
            query=request.query,
            agent=request.agent,
            limit=max_local_cards * 2,
            scoreThreshold=0.01,
        )

        search_result = await search_memory(retrieve_req, http_request)
        memories = search_result.get("memories", [])[:max_local_cards]

        # Format selected memories
        selected_memories = []
        for idx, mem in enumerate(memories):
            selected_memories.append({
                "id": mem.get("uri", f"mem-{idx:03d}"),
                "type": mem.get("category", "memory"),
                "score": mem.get("score", 0.5),
                "content": mem.get("content", mem.get("abstract", "")),
                "source": "local",
            })

        # Build packed context
        packed_context = build_packed_context(selected_memories) if packing_enabled else ""

        # Generate meter artifact
        request_id = f"trial-{uuid4().hex[:8]}"
        client = (request.context or {}).get("client", "omnimemora-trial")
        meter = generate_meter_artifact(
            request_id=request_id,
            tenant=request.tenant,
            user=request.user,
            agent=request.agent,
            client=client,
            query=request.query,
            selected_memories=selected_memories,
            remote_candidates_considered=16,
            local_cards_used=len(selected_memories),
            packing_enabled=packing_enabled,
        )

        store_meter(meter)

        explanation = {
            "local_cards_used": len(selected_memories),
            "remote_candidates_skipped": 16,
            "skip_remote_reason": "local-first coverage satisfied",
            "packing_enabled": packing_enabled,
            "abstract_preferred": False,
            "auth_mode": "internal_trial",
            "tenant_status": "active",
        }

        return InternalTrialQueryResponse(
            selected_memories=selected_memories,
            packed_context=packed_context,
            memory_tokens_injected=meter.actual_tokens_estimate,
            tokens_saved_estimate=meter.saved_tokens_estimate,
            savings_ratio=meter.savings_ratio,
            explanation=explanation,
            meter_artifact=meter.to_dict(),
        )

    finally:
        http_request.state.v2_tenant_override = None
        http_request.state.v2_user_override = None


# ==================== 启动 ====================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=config.adapter_host,
        port=config.adapter_port,
        log_level="info"
    )
