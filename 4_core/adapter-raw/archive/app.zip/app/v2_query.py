"""
V2 /memory/query endpoint with Token Savings Meter.

This module implements the unified memory query interface with:
- Token savings estimation
- Memory packing
- Local-first strategy
- Meter artifact generation
"""
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
from uuid import uuid4
import os
import loguru


@dataclass
class TokenSavingsMeter:
    """Token Savings Meter artifact - full specification."""
    request_id: str
    tenant: str
    user: str
    agent: str
    client: Optional[str]
    timestamp: str
    query_shape: str  # "field_only" or "mixed"
    query_chars: int
    query: str  # The original query text

    baseline_chars: int
    actual_chars: int
    saved_chars: int

    baseline_tokens_estimate: int
    actual_tokens_estimate: int
    saved_tokens_estimate: int

    savings_ratio: float

    packed_memory_count: int
    local_cards_used: int
    remote_candidates_considered: int
    remote_candidates_skipped: int
    remote_used_count: int

    skipped_remote_reason: Optional[str]
    coverage_satisfied: bool
    packing_enabled: bool
    abstract_preferred: bool
    dedup_applied: bool

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def estimate_tokens(chars: int) -> int:
    """Estimate token count from character count (simplified: chars / 4)."""
    return max(1, chars // 4)


def classify_query_shape(query: str) -> str:
    """Classify query shape: field_only vs mixed."""
    field_patterns = [
        "timezone", "preference", "user.", "project.", "setting.",
        "what is", "what's", "who is", "who's", "where is", "when is"
    ]
    query_lower = query.lower()

    has_field_indicator = any(pattern in query_lower for pattern in field_patterns)
    has_complex_terms = len(query.split()) > 8 or any(c in query for c in ".,!?;")

    if has_field_indicator and not has_complex_terms:
        return "field_only"
    return "mixed"


def build_packed_context(memories: List[Dict[str, Any]]) -> str:
    """Build packed context string from memories."""
    if not memories:
        return "<relevant-memories>\n</relevant-memories>"

    lines = ["<relevant-memories>"]
    for mem in memories:
        mem_type = mem.get("type", "memory")
        score = mem.get("score", 0.0)
        content = mem.get("content", "")
        score_pct = int(score * 100) if score else 0
        lines.append(f"- [{mem_type} | {score_pct}%] {content}")
    lines.append("</relevant-memories>")
    return "\n".join(lines)


def calculate_baseline_chars(memories: List[Dict[str, Any]], remote_candidates: int = 16) -> int:
    """Calculate baseline character count (all candidates without optimization)."""
    if not memories:
        return 0

    # Baseline assumes we would have fetched all remote candidates (16) as full text
    avg_mem_chars = sum(len(m.get("content", "")) for m in memories) / len(memories)
    baseline = avg_mem_chars * remote_candidates

    return int(baseline)


def generate_meter_artifact(
    request_id: str,
    tenant: str,
    user: str,
    agent: str,
    client: Optional[str],
    query: str,
    selected_memories: List[Dict[str, Any]],
    remote_candidates_considered: int = 16,
    local_cards_used: int = 4,
    packing_enabled: bool = True,
) -> TokenSavingsMeter:
    """Generate a complete Token Savings Meter artifact."""
    timestamp = datetime.utcnow().isoformat() + "Z"
    query_shape = classify_query_shape(query)
    query_chars = len(query)

    # Calculate actual chars from selected memories
    actual_chars = sum(len(m.get("content", "")) for m in selected_memories)
    packed_context = build_packed_context(selected_memories) if packing_enabled else ""
    if packing_enabled:
        actual_chars = len(packed_context)

    # Calculate baseline (what it would have been without optimization)
    baseline_chars = calculate_baseline_chars(selected_memories, remote_candidates_considered)

    # Derived savings metrics
    saved_chars = max(0, baseline_chars - actual_chars)
    baseline_tokens = estimate_tokens(baseline_chars)
    actual_tokens = estimate_tokens(actual_chars)
    saved_tokens = max(0, baseline_tokens - actual_tokens)
    savings_ratio = saved_tokens / baseline_tokens if baseline_tokens > 0 else 0.0

    # Local-first strategy defaults
    remote_candidates_skipped = remote_candidates_considered - 0  # 0 used
    skipped_remote_reason = "local-first coverage satisfied" if local_cards_used >= len(selected_memories) else None
    coverage_satisfied = True

    return TokenSavingsMeter(
        request_id=request_id,
        tenant=tenant,
        user=user,
        agent=agent,
        client=client,
        timestamp=timestamp,
        query_shape=query_shape,
        query_chars=query_chars,
        query=query,
        baseline_chars=baseline_chars,
        actual_chars=actual_chars,
        saved_chars=saved_chars,
        baseline_tokens_estimate=baseline_tokens,
        actual_tokens_estimate=actual_tokens,
        saved_tokens_estimate=saved_tokens,
        savings_ratio=round(savings_ratio, 3),
        packed_memory_count=len(selected_memories),
        local_cards_used=min(local_cards_used, len(selected_memories)),
        remote_candidates_considered=remote_candidates_considered,
        remote_candidates_skipped=remote_candidates_skipped,
        remote_used_count=0,
        skipped_remote_reason=skipped_remote_reason,
        coverage_satisfied=coverage_satisfied,
        packing_enabled=packing_enabled,
        abstract_preferred=False,
        dedup_applied=True,
    )


# In-memory storage for meter artifacts — backed by local persistence.
# Loaded lazily on first store_meter / get_meter call.
_meter_store: Dict[str, TokenSavingsMeter] = {}
_usage_aggregates: Dict[str, List[TokenSavingsMeter]] = {}
_persistence_loaded = False


# ------------------------------------------------------------------
# Local JSON persistence layer (inline — no new module introduced).
# All writes use atomic temp-then-replace to avoid partial writes.
# Files live under {adapter data}/  (same dir as tenant_access_registry.json).
#
# Layout:
#   {data}/meters_index.json     — request_id → full meter dict
#   {data}/meters_{tenant}.json  — per-tenant aggregate list
# ------------------------------------------------------------------

def _meter_index_path() -> str:
    """Absolute path to the shared meter index file."""
    import os
    adapter_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(adapter_dir, "data", "meters_index.json")


def _tenant_aggregate_path(tenant: str) -> str:
    """Absolute path to a per-tenant aggregate file.

    Tenant segment is sanitized (alphanumeric / dash / underscore only) to
    prevent path-traversal attacks.
    """
    import os
    adapter_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    safe = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in (tenant or "unknown"))
    return os.path.join(adapter_dir, "data", f"meters_{safe}.json")


def _atomic_write_json(path: str, data: Any) -> None:
    """
    Atomically serialise *data* as JSON to *path* using the
    write-to-temp-then-atomic-replace pattern.

    Steps:
    1. Create a .tmp file in the same directory as *path* (same FS → rename
       is atomic on POSIX and well-defined on Windows ≥ Vista).
    2. Write JSON with indent, flush, and fsync to push data to disk.
    3. os.replace(tmp, path) atomically commits the write.
    4. On any error the temp file is removed before re-raising.
    """
    import json, os, tempfile
    target = os.path.abspath(path)
    target_dir = os.path.dirname(target)
    if target_dir:
        os.makedirs(target_dir, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix=".tmp", prefix="v2meters_", dir=target_dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, target)  # atomic on same filesystem
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def _safe_read_json(path: str) -> Any:
    """Return the deserialised JSON at *path*, or None if missing / malformed."""
    import json, os
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def persist_meter(meter: TokenSavingsMeter) -> None:
    """
    Persist a single meter to the shared index atomically.

    The index is a flat dict  request_id → meter_dict  so that individual
    records can be loaded on cache-miss without scanning per-tenant files.
    """
    idx_path = _meter_index_path()
    index: Dict[str, Any] = _safe_read_json(idx_path) or {}
    index[meter.request_id] = meter.to_dict()
    _atomic_write_json(idx_path, index)


def persist_tenant_aggregate(tenant: str, meter: TokenSavingsMeter) -> None:
    """
    Append a meter to the per-tenant aggregate list atomically.

    One file per tenant avoids write contention on the shared index as the
    dataset grows.  The tenant slug is sanitised before use as a filename.
    """
    agg_path = _tenant_aggregate_path(tenant)
    agg_list: List[Dict[str, Any]] = _safe_read_json(agg_path) or []
    agg_list.append(meter.to_dict())
    _atomic_write_json(agg_path, agg_list)


def load_meter(request_id: str) -> Optional[Dict[str, Any]]:
    """Load a single meter dict from the shared index (lazy disk fallback)."""
    index: Dict[str, Any] = _safe_read_json(_meter_index_path()) or {}
    return index.get(request_id)


def load_persisted_state() -> tuple[Dict[str, Dict[str, Any]], Dict[str, List[Dict[str, Any]]]]:
    """
    Load all persisted state from disk on process startup.

    Returns:
        (meters_index: dict request_id→dict,
         tenant_aggregates: dict tenant_slug→list[dict])
    """
    import glob as _glob
    index: Dict[str, Dict[str, Any]] = _safe_read_json(_meter_index_path()) or {}
    tenant_aggregates: Dict[str, List[Dict[str, Any]]] = {}

    data_dir = os.path.dirname(_meter_index_path())
    for path in _glob.glob(os.path.join(data_dir, "meters_*.json")):
        basename = os.path.basename(path)
        if basename == "meters_index.json":
            continue
        slug = basename[len("meters_"):-len(".json")]
        loaded: List[Dict[str, Any]] = _safe_read_json(path) or []
        tenant_aggregates[slug] = loaded

    return index, tenant_aggregates


def _ensure_persistence_loaded() -> None:
    """Load persisted state from disk into in-memory stores (idempotent)."""
    global _persistence_loaded
    if _persistence_loaded:
        return
    _persistence_loaded = True

    try:
        # Load meter files into memory
        persisted_meters, persisted_aggregates = load_persisted_state()
        for rid, meter_dict in persisted_meters.items():
            try:
                _meter_store[rid] = TokenSavingsMeter(**meter_dict)
            except Exception:
                pass  # skip malformed records

        # Load aggregate files into memory (tenant_id -> list of meters)
        for tenant_id, agg_list in persisted_aggregates.items():
            if tenant_id not in _usage_aggregates:
                _usage_aggregates[tenant_id] = []
            for meter_dict in agg_list:
                try:
                    _usage_aggregates[tenant_id].append(TokenSavingsMeter(**meter_dict))
                except Exception:
                    pass  # skip malformed records

        loguru.logger.info(
            f"[V2_QUERY] Loaded from persistence: {len(_meter_store)} meters, "
            f"{len(_usage_aggregates)} tenant aggregates"
        )
    except Exception as exc:
        loguru.logger.warning(f"[V2_QUERY] Failed to load persisted state: {exc}")

# Quota enforcement result
@dataclass
class QuotaEnforcementResult:
    """Result of a quota enforcement check."""
    quota_exceeded: bool
    current_usage: int
    monthly_quota: Optional[int]
    quota_status: str  # "over_quota" | "within_quota" | "untracked"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "quota_exceeded": self.quota_exceeded,
            "current_usage": self.current_usage,
            "monthly_quota": self.monthly_quota,
            "quota_status": self.quota_status,
        }


def check_quota_enforcement(tenant: str, registry_entry: Optional[Dict[str, Any]]) -> QuotaEnforcementResult:
    """
    Check whether a SaaS-key-authenticated tenant has exceeded their monthly token quota.

    This function is only called for requests with auth_mode == 'omnimemora_key'.
    Returns a QuotaEnforcementResult; callers are responsible for raising HTTP 429
    when quota_exceeded is True.

    Args:
        tenant: The tenant identifier.
        registry_entry: The matched tenant registry entry (contains monthly_quota_tokens).

    Returns:
        QuotaEnforcementResult with quota_exceeded=True when current_usage > monthly_quota_tokens.
    """
    from datetime import datetime

    # Determine monthly quota from registry
    monthly_quota: Optional[int] = None
    if registry_entry:
        raw_quota = registry_entry.get("monthly_quota_tokens")
        if raw_quota not in (None, ""):
            try:
                monthly_quota = int(raw_quota)
            except (TypeError, ValueError):
                monthly_quota = None

    # Get current period usage from meter aggregates
    _ensure_persistence_loaded()
    current_usage = 0
    meters = _usage_aggregates.get(tenant, [])
    if meters:
        current_usage = sum(m.actual_tokens_estimate for m in meters)

    # Determine quota status
    if monthly_quota is None:
        quota_status = "untracked"
        quota_exceeded = False
    else:
        quota_exceeded = current_usage > monthly_quota
        quota_status = "over_quota" if quota_exceeded else "within_quota"

    return QuotaEnforcementResult(
        quota_exceeded=quota_exceeded,
        current_usage=current_usage,
        monthly_quota=monthly_quota,
        quota_status=quota_status,
    )


def store_meter(meter: TokenSavingsMeter) -> None:
    """Store meter artifact in memory and persist to disk atomically."""
    _ensure_persistence_loaded()
    _meter_store[meter.request_id] = meter

    # Aggregate by tenant
    tenant_key = meter.tenant
    if tenant_key not in _usage_aggregates:
        _usage_aggregates[tenant_key] = []
    _usage_aggregates[tenant_key].append(meter)

    # Persist atomically to disk (best-effort — failures are logged, not raised)
    try:
        persist_meter(meter)
        persist_tenant_aggregate(meter.tenant, meter)
    except Exception as exc:
        loguru.logger.warning(f"[METER] Persistence failed: {exc}")

    loguru.logger.info(f"[METER] Stored request_id={meter.request_id}, saved={meter.saved_tokens_estimate} tokens")


def get_meter(request_id: str) -> Optional[TokenSavingsMeter]:
    """Get meter artifact by request ID.

    Checks in-memory store first, then falls back to disk.
    """
    _ensure_persistence_loaded()
    if request_id in _meter_store:
        return _meter_store[request_id]

    # Disk fallback (lazy load on first miss)
    try:
        meter_dict = load_meter(request_id)
        if meter_dict:
            meter = TokenSavingsMeter(**meter_dict)
            _meter_store[request_id] = meter
            return meter
    except Exception as exc:
        loguru.logger.warning(f"[METER] get_meter disk fallback failed: {exc}")
    return None


def get_tenant_usage(tenant: str, start_time: Optional[datetime] = None, end_time: Optional[datetime] = None) -> Dict[str, Any]:
    """Get aggregated usage for a tenant."""
    _ensure_persistence_loaded()
    meters = _usage_aggregates.get(tenant, [])

    if start_time:
        meters = [m for m in meters if datetime.fromisoformat(m.timestamp.replace("Z", "+00:00")) >= start_time]
    if end_time:
        meters = [m for m in meters if datetime.fromisoformat(m.timestamp.replace("Z", "+00:00")) <= end_time]

    if not meters:
        return {
            "tenant": tenant,
            "request_count": 0,
            "total_requests": 0,
            "saved_tokens_estimate_total": 0,
            "actual_tokens_estimate_total": 0,
            "baseline_tokens_total": 0,
            "actual_tokens_total": 0,
            "saved_tokens_total": 0,
            "average_savings_ratio": 0.0,
            "last_request_at": None,
            "current_period_usage": 0,
            "by_agent": [],
            "recent_requests": [],
        }

    # Sort meters by timestamp descending (most recent first)
    sorted_meters = sorted(
        meters,
        key=lambda m: m.timestamp,
        reverse=True
    )

    total_requests = len(meters)
    baseline_total = sum(m.baseline_tokens_estimate for m in meters)
    actual_total = sum(m.actual_tokens_estimate for m in meters)
    saved_total = sum(m.saved_tokens_estimate for m in meters)
    avg_ratio = saved_total / baseline_total if baseline_total > 0 else 0.0
    last_request_at = sorted_meters[0].timestamp if sorted_meters else None

    # Aggregate by agent
    agent_map: Dict[str, List[TokenSavingsMeter]] = {}
    for m in meters:
        if m.agent not in agent_map:
            agent_map[m.agent] = []
        agent_map[m.agent].append(m)

    by_agent = []
    for agent_id, agent_meters in agent_map.items():
        agent_saved = sum(m.saved_tokens_estimate for m in agent_meters)
        agent_baseline = sum(m.baseline_tokens_estimate for m in agent_meters)
        agent_ratio = agent_saved / agent_baseline if agent_baseline > 0 else 0.0
        by_agent.append({
            "agent": agent_id,
            "saved_tokens": agent_saved,
            "savings_ratio": round(agent_ratio, 3),
        })

    # Prepare recent requests (limit to 10 most recent)
    recent_requests = []
    for m in sorted_meters[:10]:
        recent_requests.append({
            "request_id": m.request_id,
            "tenant": m.tenant,
            "user": m.user,
            "agent": m.agent,
            "timestamp": m.timestamp,
            "query": getattr(m, "query", ""),
            "baseline_tokens": m.baseline_tokens_estimate,
            "actual_tokens": m.actual_tokens_estimate,
            "saved_tokens": m.saved_tokens_estimate,
            "savings_ratio": m.savings_ratio,
            "baseline_chars": m.baseline_chars,
            "actual_chars": m.actual_chars,
            "saved_chars": m.saved_chars,
            "local_cards_used": m.local_cards_used,
            "remote_candidates_considered": m.remote_candidates_considered,
            "remote_candidates_skipped": m.remote_candidates_skipped,
            "skipped_remote_reason": m.skipped_remote_reason,
            "packing_enabled": m.packing_enabled,
            "dedup_applied": m.dedup_applied,
        })

    return {
        "tenant": tenant,
        "request_count": total_requests,
        "total_requests": total_requests,
        "saved_tokens_estimate_total": saved_total,
        "actual_tokens_estimate_total": actual_total,
        "baseline_tokens_total": baseline_total,
        "actual_tokens_total": actual_total,
        "saved_tokens_total": saved_total,
        "average_savings_ratio": round(avg_ratio, 3),
        "last_request_at": last_request_at,
        "current_period_usage": actual_total,
        "by_agent": by_agent,
        "recent_requests": recent_requests,
    }


def get_trend_data(tenant: str, days: int = 7) -> Dict[str, Any]:
    """Get trend data for the last N days."""
    from datetime import timedelta

    _ensure_persistence_loaded()
    meters = _usage_aggregates.get(tenant, [])
    end_date = datetime.utcnow().date()
    start_date = end_date - timedelta(days=days - 1)

    # Group by date
    date_map: Dict[str, List[TokenSavingsMeter]] = {}
    for i in range(days):
        date = start_date + timedelta(days=i)
        date_key = date.isoformat()
        date_map[date_key] = []

    for m in meters:
        m_date = datetime.fromisoformat(m.timestamp.replace("Z", "+00:00")).date()
        date_key = m_date.isoformat()
        if date_key in date_map:
            date_map[date_key].append(m)

    trend = []
    for date_key in sorted(date_map.keys()):
        day_meters = date_map[date_key]
        requests = len(day_meters)
        saved_tokens = sum(m.saved_tokens_estimate for m in day_meters)
        baseline_total = sum(m.baseline_tokens_estimate for m in day_meters)
        savings_ratio = saved_tokens / baseline_total if baseline_total > 0 else 0.0

        trend.append({
            "date": date_key,
            "requests": requests,
            "saved_tokens": saved_tokens,
            "savings_ratio": round(savings_ratio, 3),
        })

    return {
        "tenant": tenant,
        "days": days,
        "trend": trend,
    }
