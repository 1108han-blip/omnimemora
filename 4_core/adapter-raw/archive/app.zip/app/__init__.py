# Memory Adapter for OpenViking
